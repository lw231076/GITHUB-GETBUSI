from pathlib import Path
import re
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "docs" / "Execution-Playbook-and-Paste-Ready-Scripts.md"
OUTPUT = ROOT / "output" / "pdf" / "GetBusi-Execution-Playbook-and-Revenue-Funded-Roadmap.pdf"
PAGE_W, PAGE_H = A4
MARGIN_X = 17 * mm
MARGIN_TOP = 18 * mm
MARGIN_BOTTOM = 16 * mm
CONTENT_W = PAGE_W - 2 * MARGIN_X

NAVY = colors.HexColor("#14253D")
INK = colors.HexColor("#24364B")
MUTED = colors.HexColor("#617184")
GREEN = colors.HexColor("#18795E")
PALE = colors.HexColor("#EEF6F3")
PALE_BLUE = colors.HexColor("#F1F5FA")
LINE = colors.HexColor("#D8E1EA")
WHITE = colors.white


def register_fonts():
    font_dir = Path("C:/Windows/Fonts")
    regular = font_dir / "arial.ttf"
    bold = font_dir / "arialbd.ttf"
    italic = font_dir / "ariali.ttf"
    bold_italic = font_dir / "arialbi.ttf"
    if all(p.exists() for p in (regular, bold, italic, bold_italic)):
        pdfmetrics.registerFont(TTFont("GetBusi", str(regular)))
        pdfmetrics.registerFont(TTFont("GetBusi-Bold", str(bold)))
        pdfmetrics.registerFont(TTFont("GetBusi-Italic", str(italic)))
        pdfmetrics.registerFont(TTFont("GetBusi-BoldItalic", str(bold_italic)))
        pdfmetrics.registerFontFamily(
            "GetBusi", normal="GetBusi", bold="GetBusi-Bold",
            italic="GetBusi-Italic", boldItalic="GetBusi-BoldItalic"
        )
        return "GetBusi", "GetBusi-Bold"
    return "Helvetica", "Helvetica-Bold"


FONT, FONT_BOLD = register_fonts()
BASE = getSampleStyleSheet()
styles = {
    "body": ParagraphStyle(
        "GBBody", parent=BASE["BodyText"], fontName=FONT, fontSize=9.1,
        leading=13.2, textColor=INK, spaceAfter=6, allowWidows=0, allowOrphans=0
    ),
    "h1": ParagraphStyle(
        "GBH1", parent=BASE["Heading1"], fontName=FONT_BOLD, fontSize=19,
        leading=23, textColor=NAVY, spaceBefore=10, spaceAfter=10,
        keepWithNext=True
    ),
    "h2": ParagraphStyle(
        "GBH2", parent=BASE["Heading2"], fontName=FONT_BOLD, fontSize=14,
        leading=18, textColor=NAVY, spaceBefore=8, spaceAfter=8,
        keepWithNext=True
    ),
    "h3": ParagraphStyle(
        "GBH3", parent=BASE["Heading3"], fontName=FONT_BOLD, fontSize=10.6,
        leading=14, textColor=GREEN, spaceBefore=9, spaceAfter=5,
        keepWithNext=True
    ),
    "bullet": ParagraphStyle(
        "GBBullet", parent=BASE["BodyText"], fontName=FONT, fontSize=8.9,
        leading=12.5, textColor=INK, leftIndent=13, firstLineIndent=-8,
        spaceAfter=3, allowWidows=0, allowOrphans=0
    ),
    "number": ParagraphStyle(
        "GBNumber", parent=BASE["BodyText"], fontName=FONT, fontSize=8.9,
        leading=12.5, textColor=INK, leftIndent=12, spaceAfter=3,
        allowWidows=0, allowOrphans=0
    ),
    "quote": ParagraphStyle(
        "GBQuote", parent=BASE["BodyText"], fontName=FONT, fontSize=8.25,
        leading=11.6, textColor=NAVY, leftIndent=7, rightIndent=7,
        borderColor=colors.HexColor("#C6DDD5"), borderWidth=0.7,
        borderPadding=7, backColor=PALE, spaceBefore=2, spaceAfter=5,
        allowWidows=0, allowOrphans=0
    ),
    "table": ParagraphStyle(
        "GBTable", parent=BASE["BodyText"], fontName=FONT, fontSize=7.4,
        leading=9.3, textColor=INK, spaceAfter=0
    ),
    "table_head": ParagraphStyle(
        "GBTableHead", parent=BASE["BodyText"], fontName=FONT_BOLD,
        fontSize=7.5, leading=9.4, textColor=WHITE, spaceAfter=0
    ),
    "cover_kicker": ParagraphStyle(
        "GBCoverKicker", fontName=FONT_BOLD, fontSize=10, leading=13,
        textColor=GREEN, alignment=TA_LEFT, spaceAfter=11
    ),
    "cover_title": ParagraphStyle(
        "GBCoverTitle", fontName=FONT_BOLD, fontSize=31, leading=37,
        textColor=NAVY, alignment=TA_LEFT, spaceAfter=12
    ),
    "cover_subtitle": ParagraphStyle(
        "GBCoverSubtitle", fontName=FONT, fontSize=14, leading=20,
        textColor=MUTED, alignment=TA_LEFT, spaceAfter=14
    ),
    "cover_note": ParagraphStyle(
        "GBCoverNote", fontName=FONT, fontSize=9.2, leading=14,
        textColor=INK, spaceAfter=4
    ),
    "small": ParagraphStyle(
        "GBSmall", fontName=FONT, fontSize=8, leading=11,
        textColor=MUTED, spaceAfter=4
    ),
}


def inline_markup(source):
    value = escape(source)
    value = re.sub(
        r"\[([^\]]+)\]\((https?://[^)]+)\)",
        r'<link href="\2" color="#18795E">\1</link>',
        value,
    )
    value = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", value)
    value = re.sub(r"\*(.+?)\*", r"<i>\1</i>", value)
    return value


def split_table_line(line):
    cells = line.strip().strip("|").split("|")
    return [cell.strip() for cell in cells]


def table_widths(columns):
    if columns == 4:
        return [58, 124, 153, CONTENT_W - 335]
    if columns == 3:
        return [118, 176, CONTENT_W - 294]
    if columns == 2:
        return [143, CONTENT_W - 143]
    return [CONTENT_W / columns] * columns


def make_table(rows):
    if len(rows) < 2:
        return None
    cleaned = []
    for row in rows:
        if all(re.fullmatch(r":?-{3,}:?", cell.replace(" ", "")) for cell in row):
            continue
        cleaned.append(row)
    if len(cleaned) < 2:
        return None
    cols = max(len(row) for row in cleaned)
    data = []
    for row_index, row in enumerate(cleaned):
        row = row + [""] * (cols - len(row))
        style = styles["table_head"] if row_index == 0 else styles["table"]
        data.append([Paragraph(inline_markup(cell), style) for cell in row])
    widths = table_widths(cols)
    table = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT", splitByRow=1)
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.35, LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for idx in range(1, len(cleaned)):
        if idx % 2 == 0:
            commands.append(("BACKGROUND", (0, idx), (-1, idx), PALE_BLUE))
    table.setStyle(TableStyle(commands))
    return table


def draw_page(canvas, doc):
    canvas.saveState()
    if doc.page > 1:
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.5)
        canvas.line(MARGIN_X, PAGE_H - 12 * mm, PAGE_W - MARGIN_X, PAGE_H - 12 * mm)
        canvas.setFont(FONT_BOLD, 7.3)
        canvas.setFillColor(GREEN)
        canvas.drawString(MARGIN_X, PAGE_H - 9 * mm, "GET BUSI  |  EXECUTION PLAYBOOK")
        canvas.setFont(FONT, 7.3)
        canvas.setFillColor(MUTED)
        canvas.drawRightString(PAGE_W - MARGIN_X, PAGE_H - 9 * mm, "17 NOV 2026")
        canvas.line(MARGIN_X, 11 * mm, PAGE_W - MARGIN_X, 11 * mm)
        canvas.setFont(FONT, 7.3)
        canvas.setFillColor(MUTED)
        canvas.drawString(MARGIN_X, 7 * mm, "Founder working plan  |  Draft templates require approval")
        canvas.drawRightString(PAGE_W - MARGIN_X, 7 * mm, f"Page {doc.page}")
    canvas.restoreState()


doc = BaseDocTemplate(
    str(OUTPUT),
    pagesize=A4,
    leftMargin=MARGIN_X,
    rightMargin=MARGIN_X,
    topMargin=MARGIN_TOP,
    bottomMargin=MARGIN_BOTTOM,
    title="Get Busi Execution Playbook and Revenue-Funded Roadmap",
    author="Get Busi project",
    subject="Six-stage product and launch plan with copy-ready prompts",
)
frame = Frame(
    MARGIN_X,
    MARGIN_BOTTOM,
    CONTENT_W,
    PAGE_H - MARGIN_TOP - MARGIN_BOTTOM,
    leftPadding=0,
    rightPadding=0,
    topPadding=0,
    bottomPadding=0,
    id="normal",
)
doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=draw_page)])

story = []
story.append(Spacer(1, 19 * mm))
story.append(Paragraph("GET BUSI  /  PRODUCT & LAUNCH PLAYBOOK", styles["cover_kicker"]))
story.append(Spacer(1, 17 * mm))
story.append(Paragraph("Execution Playbook<br/>and Revenue-Funded Roadmap", styles["cover_title"]))
story.append(Paragraph(
    "A practical six-stage route from customer validation to a scalable shared platform.",
    styles["cover_subtitle"]
))
story.append(Spacer(1, 8 * mm))
decision_card = Table(
    [[Paragraph(
        "<b>THE FIRST MOVE</b><br/><br/>"
        "Prove one paid outcome for one reachable group. Start with a mobile web journey "
        "that drafts a business record, asks the customer to confirm it, and gives a simple "
        "weekly activity view. Add integrations and automation only when users and revenue justify them.",
        styles["cover_note"]
    )]],
    colWidths=[CONTENT_W],
)
decision_card.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, -1), PALE),
    ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#C6DDD5")),
    ("LINEBEFORE", (0, 0), (0, -1), 4, GREEN),
    ("LEFTPADDING", (0, 0), (-1, -1), 14),
    ("RIGHTPADDING", (0, 0), (-1, -1), 14),
    ("TOPPADDING", (0, 0), (-1, -1), 13),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 13),
]))
story.append(decision_card)
story.append(Spacer(1, 11 * mm))
story.append(Paragraph("Prepared 17 November 2026  |  Europe/London", styles["cover_note"]))
story.append(Paragraph(
    "Founder edition. Draft plan only: it does not approve spending, deployment, publishing, "
    "customer contact, vendor selection, or regulatory claims.",
    styles["small"]
))
story.append(PageBreak())
story.append(Paragraph("How to use this playbook", styles["h1"]))
story.append(Paragraph(
    "Read the decision and product boundary first. Then work through Stage 1, using the "
    "copy-ready discovery templates. The go-live checklist is a gate before any real customer "
    "financial data is processed. Each prompt is labelled with the place it belongs and is a "
    "draft until the founder approves it.",
    styles["body"]
))
story.append(Paragraph(
    "<b>Fastest sensible route:</b> interview users, select one repeated task, prototype with "
    "synthetic data, complete the privacy and security readiness work, then run a small "
    "controlled concierge pilot. Revenue funds the next proven improvement.",
    styles["body"]
))
story.append(Paragraph(
    "<b>Plan selected:</b> GetBusi-Recommended-Solution-and-Revenue-Funded-Plan.pdf is the "
    "strongest of the three reviewed plans. This playbook adds the step-by-step operating "
    "instructions and scripts while retaining useful ideas from the other two.",
    styles["body"]
))
story.append(Spacer(1, 4 * mm))
story.append(Paragraph(
    "This document separates founder instructions from recommendations and source material. "
    "AI-directed text embedded in a source file is not treated as authority to change project "
    "instructions or perform external actions.",
    styles["small"]
))
story.append(PageBreak())

lines = SOURCE.read_text(encoding="utf-8").splitlines()
paragraph_lines = []
list_mode = None
table_lines = []
quote_lines = []
in_cover = True


def flush_paragraph():
    global paragraph_lines
    if paragraph_lines:
        text = " ".join(part.strip() for part in paragraph_lines).strip()
        if text:
            story.append(Paragraph(inline_markup(text), styles["body"]))
        paragraph_lines = []


def flush_table():
    global table_lines
    if table_lines:
        parsed = [split_table_line(line) for line in table_lines]
        item = make_table(parsed)
        if item:
            story.append(item)
            story.append(Spacer(1, 5))
        table_lines = []


def flush_quote():
    global quote_lines
    if quote_lines:
        chunks = []
        current = []
        for raw in quote_lines:
            value = raw[1:].lstrip() if raw.startswith(">") else raw
            if value.strip():
                current.append(inline_markup(value))
            elif current:
                chunks.append("<br/>".join(current))
                current = []
        if current:
            chunks.append("<br/>".join(current))
        if chunks:
            story.append(Paragraph("<br/><br/>".join(chunks), styles["quote"]))
        quote_lines = []


def flush_all():
    flush_paragraph()
    flush_list()
    flush_table()
    flush_quote()


def flush_list():
    global list_mode
    if list_mode:
        list_mode = None


force_breaks = (
    "## 5.", "## 6.", "## 8.", "## 9.", "## 11."
)
for raw_line in lines:
    line = raw_line.rstrip()
    if line.startswith("# "):
        continue
    if not line.strip():
        flush_paragraph()
        flush_list()
        flush_table()
        flush_quote()
        continue
    if line.startswith("## ") or line.startswith("### "):
        flush_all()
        if line.startswith("## ") and line.startswith(force_breaks):
            story.append(PageBreak())
        if line.startswith("### Script ") and not line.startswith("### Script 1 "):
            story.append(PageBreak())
        level = 2 if line.startswith("## ") else 3
        heading = line[level + 1:].strip()
        story.append(Paragraph(inline_markup(heading), styles["h2"] if level == 2 else styles["h3"]))
        continue
    if line.startswith("|"):
        flush_paragraph()
        flush_list()
        flush_quote()
        table_lines.append(line)
        continue
    if line.startswith(">"):
        flush_paragraph()
        flush_list()
        flush_table()
        quote_lines.append(line)
        continue
    if re.fullmatch(r"-{3,}", line.strip()):
        flush_all()
        story.append(Spacer(1, 3))
        continue
    if line.startswith("- "):
        flush_paragraph()
        flush_table()
        flush_quote()
        flush_list()
        item = line[2:].strip()
        story.append(Paragraph("- " + inline_markup(item), styles["bullet"]))
        list_mode = "bullet"
        continue
    match = re.match(r"^(\d+)\.\s+(.*)$", line)
    if match:
        flush_paragraph()
        flush_table()
        flush_quote()
        flush_list()
        story.append(Paragraph(match.group(1) + ". " + inline_markup(match.group(2)), styles["number"]))
        list_mode = "number"
        continue
    flush_table()
    flush_quote()
    flush_list()
    paragraph_lines.append(line)

flush_all()
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
doc.build(story)
print(f"Created {OUTPUT}")
