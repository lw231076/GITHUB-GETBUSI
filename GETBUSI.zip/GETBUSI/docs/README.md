# Get Busi Project Home

**Prepared:** 17 November 2026

This folder is the working home for the Get Busi product and launch. The Codex project “GET BUSI” already points here and is grouped in the “Get Busi Build” sidebar section.

## Start here
- [Recommended Solution and Revenue-Funded Plan](Recommended-Solution-and-Revenue-Funded-Plan.md): current source of truth for the final product, API choices, six-stage roadmap, revenue gates, and comparison of the four blueprints.
- [Launch Plan](Launch-Plan.md): staged route from discovery to paid pilot and product expansion.
- [Collaboration and Tool Operating Model](Collaboration-and-Tool-Operating-Model.md): which tools to use and how to coordinate AI and human work.
- [Source Review and Decisions](Source-Review-and-Decisions.md): evidence, assumptions, decisions, and unresolved questions.
- [Project memory](../memory/projects/get-busi.md): stable context.
- [Technology stack](../memory/context/technology-stack.md): available tools and recommended roles.
- [Earlier target solution draft](Target-Solution-and-6-Stage-Roadmap.md): retained as a previous planning version; use the recommended plan above for current decisions.

## Memory
- AGENTS.md gives Codex project guidance.
- CLAUDE.md gives Claude a short working-memory index.
- memory/ stores deeper project context and terms.

## How to update
When the founder makes a decision, update the relevant memory or decision log. Mark every product, pricing, compliance, and infrastructure fact with a source or a “to confirm” label. Do not store passwords, customer records, or API keys here.
